library(testthat)
library(rmBayes)

test_check("rmBayes")
